import { useState } from 'react';
import axios from 'axios';

export default function Home() {
  const [prompt, setPrompt] = useState('');
  const [response, setResponse] = useState('');

  const generateBrief = async () => {
    const res = await axios.post('http://localhost:5000/api/generate', { prompt });
    setResponse(res.data.result);
  };

  return (
    <main className="p-6 max-w-3xl mx-auto">
      <h1 className="text-3xl font-bold mb-4">AutoBrief – Client Brief Generator</h1>
      <textarea
        className="w-full p-4 border rounded"
        rows={6}
        placeholder="Enter project description..."
        value={prompt}
        onChange={(e) => setPrompt(e.target.value)}
      />
      <button
        className="mt-4 bg-blue-600 text-white px-4 py-2 rounded"
        onClick={generateBrief}
      >
        Generate Brief
      </button>
      <div className="mt-6 p-4 bg-gray-100 rounded">{response}</div>
    </main>
  );
}